ROCKET RUNNER - UNITY PROJECT

Open this folder in Unity Hub and open the project.

Main scene:
Assets/Scenes/Main.unity

IMPORTANT:
The project includes the scripts and a runtime bootstrap for the requested gameplay:
- Rocket
- Small stone obstacles
- 3 hearts
- Score
- Left/Right controls
- Speed tiers:
  0-99 = 8
  100-199 = 14
  200+ = 20

If the included scene does not auto-start the bootstrap in your Unity version:
1. Open Assets/Scenes/Main.unity
2. Create an empty GameObject
3. Add the RocketRunnerBootstrap component
4. Press Play.

The game uses Unity primitive shapes at runtime, so no external art assets are required.
