using UnityEngine;

public class StoneSpawner : MonoBehaviour
{
    public GameObject stonePrefab;
    public float spawnInterval = 1.5f;

    public float baseSpeed = 8f;
    public float mediumSpeed = 14f;
    public float highSpeed = 20f;

    public Vector3 stoneScale = new Vector3(0.5f, 0.5f, 0.5f);

    RocketController rocketScript;

    void Start()
    {
        rocketScript = FindObjectOfType<RocketController>();
        InvokeRepeating(nameof(SpawnStone), 1f, spawnInterval);
    }

    public void CreateRuntimeStonePrefab()
    {
        if (stonePrefab != null) return;

        var root = new GameObject("StonePrefab_Runtime");
        root.tag = "Stone";

        var mesh = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        mesh.transform.SetParent(root.transform);
        mesh.transform.localPosition = Vector3.zero;
        mesh.transform.localScale = Vector3.one;
        mesh.GetComponent<Renderer>().material.color = new Color(0.35f,0.38f,0.42f);

        var col = root.AddComponent<SphereCollider>();
        col.isTrigger = true;
        root.SetActive(false);
        stonePrefab = root;
    }

    void SpawnStone()
    {
        if (stonePrefab == null) return;

        float randomX = Random.Range(-5f, 5f);
        Vector3 spawnPos = new Vector3(randomX, transform.position.y, transform.position.z);
        GameObject stone = Instantiate(stonePrefab, spawnPos, Quaternion.identity);
        stone.SetActive(true);
        stone.transform.localScale = stoneScale;

        float currentSpeed = baseSpeed;
        if (rocketScript != null)
        {
            if (rocketScript.score >= 200) currentSpeed = highSpeed;
            else if (rocketScript.score >= 100) currentSpeed = mediumSpeed;
        }

        Rigidbody rb = stone.GetComponent<Rigidbody>();
        if (rb == null) rb = stone.AddComponent<Rigidbody>();
        rb.useGravity = false;
        rb.isKinematic = false;
        rb.velocity = Vector3.back * currentSpeed;

        Destroy(stone, 6f);
    }
}
