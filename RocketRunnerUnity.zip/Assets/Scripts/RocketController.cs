using UnityEngine;
using UnityEngine.UI;

public class RocketController : MonoBehaviour
{
    public float moveSpeed = 8f;
    public int lives = 3;
    public int score = 0;
    public Text scoreText;
    public GameObject[] heartIcons;

    float scoreTimer;

    void Update()
    {
        if (Time.timeScale == 0) return;

        scoreTimer += Time.deltaTime * 10f;
        score = (int)scoreTimer;
        if (scoreText != null) scoreText.text = "SCORE: " + score;

        float input = Input.GetAxisRaw("Horizontal");
        transform.Translate(Vector3.right * input * moveSpeed * Time.deltaTime);

        transform.position = new Vector3(
            Mathf.Clamp(transform.position.x, -5f, 5f),
            transform.position.y,
            transform.position.z
        );
    }

    public void MoveLeft()
    {
        transform.position += Vector3.left * 0.9f;
        Clamp();
    }

    public void MoveRight()
    {
        transform.position += Vector3.right * 0.9f;
        Clamp();
    }

    void Clamp()
    {
        Vector3 p = transform.position;
        p.x = Mathf.Clamp(p.x, -5f, 5f);
        transform.position = p;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Stone"))
        {
            Destroy(other.gameObject);
            TakeDamage();
        }
    }

    void TakeDamage()
    {
        lives--;
        if (heartIcons != null && lives >= 0 && lives < heartIcons.Length)
            heartIcons[lives].SetActive(false);

        if (lives <= 0)
        {
            Time.timeScale = 0;
            Debug.Log("Game Over! Final Score: " + score);
        }
    }
}
