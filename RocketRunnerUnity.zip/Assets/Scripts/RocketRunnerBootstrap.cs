using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class RocketRunnerBootstrap : MonoBehaviour
{
    RocketController player;
    StoneSpawner spawner;
    Text scoreText;
    readonly List<GameObject> hearts = new List<GameObject>();
    Canvas canvas;

    void Start()
    {
        SetupWorld();
        SetupUI();
        SetupPlayer();
        SetupSpawner();
    }

    void SetupWorld()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            var go = new GameObject("Main Camera");
            cam = go.AddComponent<Camera>();
            go.tag = "MainCamera";
        }
        cam.transform.position = new Vector3(0, 4.5f, 10);
        cam.transform.rotation = Quaternion.Euler(18, 180, 0);
        cam.fieldOfView = 60;

        var lightGo = new GameObject("Directional Light");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        lightGo.transform.rotation = Quaternion.Euler(35, 0, 0);

        var road = GameObject.CreatePrimitive(PrimitiveType.Cube);
        road.name = "Runner Track";
        road.transform.position = new Vector3(0, -1.2f, -20);
        road.transform.localScale = new Vector3(12, 0.5f, 80);
        road.GetComponent<Renderer>().material.color = new Color(0.06f, 0.08f, 0.12f);
    }

    void SetupPlayer()
    {
        var go = new GameObject("Rocket");
        go.transform.position = new Vector3(0, 0, 4);
        var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        body.transform.SetParent(go.transform);
        body.transform.localPosition = Vector3.zero;
        body.transform.localRotation = Quaternion.Euler(90, 0, 0);
        body.transform.localScale = new Vector3(0.65f, 1.1f, 0.65f);
        body.GetComponent<Renderer>().material.color = new Color(0.8f, 0.9f, 1f);
        var rb = go.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        go.AddComponent<CapsuleCollider>().isTrigger = true;
        player = go.AddComponent<RocketController>();
        player.moveSpeed = 8f;
        player.lives = 3;
        player.scoreText = scoreText;
        player.heartIcons = hearts.ToArray();
    }

    void SetupSpawner()
    {
        var go = new GameObject("StoneSpawner");
        go.transform.position = new Vector3(0, 0, 22);
        spawner = go.AddComponent<StoneSpawner>();
        spawner.spawnInterval = 1.5f;
        spawner.baseSpeed = 8f;
        spawner.mediumSpeed = 14f;
        spawner.highSpeed = 20f;
        spawner.stoneScale = new Vector3(0.5f, 0.5f, 0.5f);
        spawner.CreateRuntimeStonePrefab();
    }

    void SetupUI()
    {
        var cgo = new GameObject("UI");
        canvas = cgo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        cgo.AddComponent<CanvasScaler>();
        cgo.AddComponent<GraphicRaycaster>();

        var scoreGo = new GameObject("Score");
        scoreGo.transform.SetParent(cgo.transform);
        scoreText = scoreGo.AddComponent<Text>();
        scoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        scoreText.fontSize = 32;
        scoreText.color = Color.white;
        scoreText.alignment = TextAnchor.UpperLeft;
        var scoreRect = scoreText.rectTransform;
        scoreRect.anchorMin = new Vector2(0,1);
        scoreRect.anchorMax = new Vector2(0,1);
        scoreRect.pivot = new Vector2(0,1);
        scoreRect.anchoredPosition = new Vector2(25,-20);
        scoreRect.sizeDelta = new Vector2(300,60);
        scoreText.text = "SCORE: 0";

        for (int i=0;i<3;i++)
        {
            var h = new GameObject("Heart_" + i);
            h.transform.SetParent(cgo.transform);
            var t = h.AddComponent<Text>();
            t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            t.fontSize = 34;
            t.text = "♥";
            t.color = Color.red;
            t.alignment = TextAnchor.MiddleCenter;
            var r = t.rectTransform;
            r.anchorMin = new Vector2(1,1);
            r.anchorMax = new Vector2(1,1);
            r.pivot = new Vector2(1,1);
            r.anchoredPosition = new Vector2(-25 - i*42,-22);
            r.sizeDelta = new Vector2(38,45);
            hearts.Add(h);
        }

        MakeButton("LEFT", new Vector2(95,70), () => player?.MoveLeft());
        MakeButton("RIGHT", new Vector2(225,70), () => player?.MoveRight());
    }

    void MakeButton(string label, Vector2 pos, UnityEngine.Events.UnityAction action)
    {
        var bgo = new GameObject(label);
        bgo.transform.SetParent(canvas.transform);
        var img = bgo.AddComponent<Image>();
        img.color = new Color(1,1,1,0.18f);
        var b = bgo.AddComponent<Button>();
        b.onClick.AddListener(action);
        var r = bgo.GetComponent<RectTransform>();
        r.anchorMin = new Vector2(0,0);
        r.anchorMax = new Vector2(0,0);
        r.pivot = new Vector2(0,0);
        r.anchoredPosition = pos;
        r.sizeDelta = new Vector2(110,60);

        var txtGo = new GameObject("Text");
        txtGo.transform.SetParent(bgo.transform);
        var txt = txtGo.AddComponent<Text>();
        txt.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        txt.fontSize = 22;
        txt.color = Color.white;
        txt.alignment = TextAnchor.MiddleCenter;
        txt.text = label;
        txt.rectTransform.anchorMin = Vector2.zero;
        txt.rectTransform.anchorMax = Vector2.one;
        txt.rectTransform.offsetMin = Vector2.zero;
        txt.rectTransform.offsetMax = Vector2.zero;
    }
}
